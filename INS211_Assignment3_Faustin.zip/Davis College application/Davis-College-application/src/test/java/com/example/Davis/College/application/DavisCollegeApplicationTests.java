package com.example.Davis.College.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DavisCollegeApplicationTests {

	@Test
	void contextLoads() {
	}

}
