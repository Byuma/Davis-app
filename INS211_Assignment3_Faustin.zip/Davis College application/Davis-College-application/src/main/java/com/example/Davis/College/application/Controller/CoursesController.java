package com.example.Davis.College.application.Controller;
import com.example.Davis.College.application.Entity.Courses;
import com.example.Davis.College.application.repository.CoursesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CoursesController {
        @Autowired
        private CoursesRepository repository;
        @GetMapping("/courselist")
        public String viewCategories(Model model){
            model.addAttribute("courseList",repository.findAll());
            return "courseList";
        }
        @PostMapping("/catadd")
        public String addCourse(Courses course,Model model){
            model.addAttribute("category",new Courses());
            repository.save(course);
            return "redirect:/courselist";
        }

    }

