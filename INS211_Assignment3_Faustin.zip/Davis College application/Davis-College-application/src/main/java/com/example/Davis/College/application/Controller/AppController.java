package com.example.Davis.College.application.Controller;

import com.example.Davis.College.application.Entity.Courses;
import com.example.Davis.College.application.repository.CoursesRepository;
import com.example.Davis.College.application.repository.StudentRepository;
import com.example.Davis.College.application.Entity.Student;
import com.example.Davis.College.application.repository.CoursesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AppController {
    @Autowired
    CoursesRepository coursesRepository;
    @GetMapping("/")
    public String showHome(Model model){
        model.addAttribute("product",new StudentController());
        model.addAttribute("categoryList",coursesRepository.findAll());
        return "index";
    }
}

