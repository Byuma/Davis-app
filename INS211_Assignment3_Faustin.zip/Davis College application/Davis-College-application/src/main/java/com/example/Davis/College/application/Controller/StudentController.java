package com.example.Davis.College.application.Controller;

import com.example.Davis.College.application.Entity.Student;
import com.example.Davis.College.application.repository.CoursesRepository;
import com.example.Davis.College.application.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class StudentController{
    @Autowired
    private StudentRepository repository;
    @Autowired
    CoursesRepository coursesRepository;
    @GetMapping("/students")
    public String showStudent(Model model){
        model.addAttribute("studentList",repository.findAll());
        return "liststudents";
    }

    @PostMapping("/addstudent")
    public String addProduct(Student student){
        repository.save(student);
        return "redirect:/students";
    }
    @GetMapping("/delete/{id}")
    public String deleteStudent(@PathVariable("id") Integer id){
        repository.deleteById(id);
        return"redirect:/students";
    }
    @GetMapping("/edit/{id}")
    public String updateStudent(@PathVariable("id") Integer id, Model model){
        model.addAttribute("product", repository.findById(id).get());
        model.addAttribute("categoryList",coursesRepository.findAll());
        return"editstudent";
    }
}

