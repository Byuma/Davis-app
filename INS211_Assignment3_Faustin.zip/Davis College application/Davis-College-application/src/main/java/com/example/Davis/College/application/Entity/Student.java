package com.example.Davis.College.application.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer stdId;
    @Column(nullable = false, unique = true,length = 50)
    String stdName;
    String stdProgram;
    String stdSex;

}
